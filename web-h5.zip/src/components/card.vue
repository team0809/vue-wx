<template>
  <div>
    <p class="card">
      {{text}}
    </p>
  </div>
</template>

<script>
export default {
  props: ['text'],
  mounted() {
    debugger;
    console.log(22222222222221)
    // this.goodList = await api.hotGoods(this.params.hotGoods);
  }
}
</script>

<style>
.card {
  padding: 10px;
}
</style>
