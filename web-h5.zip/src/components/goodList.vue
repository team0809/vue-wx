<template>
<div>
    <div @click="goodsDetail(item.goodsId,item.goodsType.type,item.goodsName)" class="shop-list" v-for="(item,index) in goodList" :key="index">
      <image class="imgs" :src="item.thumbnailImgUrl" alt="" />
      <div class="list-cont">
        <div class="goods_title">
        <span class="platform">{{item.goodsType.name}}</span> {{item.goodsName}}
        </div>
          <div class="col-yuan">
          <span>
            <span class="afprice">
              <i>{{item.hasCoupon?'券后:':'售价'}}¥</i>{{item.couponAfterPrice}}
            </span>
            <span v-if="item.hasCoupon" class="price">原价:¥{{item.salePrice}} </span>
          </span>
          <span class="fr">已售{{item.volume}}件</span>
        </div>
        <div class="col-money">
          <p class="p-fr">
            <i class="quan">{{item.couponPrice}}元券</i>
          </p>
          <span class="s-k" v-if="item.showPromotion">
            <i>佣金 ¥</i>{{item.promotionPrice}}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { client,mta,api } from "../utils";

export default {
  goodList:[{}],
  props: ['text'],
  onCreate(){
    debugger;
    console.log(22222222222222220)
  },
  mounted() {
    debugger;
    console.log(22222222222221)
    // this.goodList = await api.hotGoods(this.params.hotGoods);
  },
  methods: {
    goodsDetail(id,type,goodsName) {
      mta.Event.stat("home_click_goods",{goodsName:goodsName,goodsId:id});
      client.navigateTo({
        url:"/pages/goods/main?goodsId="+id+"&goodsType="+type
      });
    },
    loadData(){
      console.log(2222222222222223);
    }
  }
}
</script>

<style>
.card {
  padding: 10px;
}
</style>
