module.exports = {
  "plugins": {
    "postcss-mpvue-wxss": {}
  }
}
